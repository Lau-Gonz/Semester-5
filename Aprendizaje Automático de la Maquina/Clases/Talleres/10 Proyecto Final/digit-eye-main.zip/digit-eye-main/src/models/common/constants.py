import torch

CUDA_IS_AVAILABLE = torch.cuda.is_available()
