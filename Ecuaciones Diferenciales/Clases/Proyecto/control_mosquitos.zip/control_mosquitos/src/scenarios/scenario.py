import numpy as np
import numpy.typing as npt
from abc import ABC, abstractmethod
from src.solvers import EulerSolver
from src.common import Variables
from .common.types import (
    MosquitoPopulations,
    MosquitoPopulation,
    GrowthIndex,
    SetIndex,
)
from typing import Literal, Any


class Scenario(ABC):
    local_load_capacities: tuple[float, float, float]
    efforts_effectiveness: tuple[float, float, float]
    mosquito_populations: MosquitoPopulations

    initial_population = 10
    initial_time = 0

    beginning_number_of_months = 0
    final_number_of_months = 6

    solver: type[EulerSolver]

    _growth_constants = [1, 2]

    def __init__(self, solver: type[EulerSolver]) -> None:
        super().__init__()
        self.solver = solver

    def get_mosquito_populations(self) -> MosquitoPopulations:
        return {
            "set_1": self.get_mosquito_population(0),
            "set_2": self.get_mosquito_population(1),
            "set_3": self.get_mosquito_population(2),
        }

    def get_mosquito_population(self, set: SetIndex) -> MosquitoPopulation:
        return {
            "growth_1": [self.get_mosquito_population_by_growth(0, set)],
            "growth_2": [self.get_mosquito_population_by_growth(1, set)],
        }

    def get_mosquito_population_by_growth(
        self, growth: GrowthIndex, set: SetIndex
    ) -> float:
        solver = self.solver(
            function=self._get_mosquito_population_function(growth, set),
            initial_t_condition=self.initial_time,
            initial_y_condition=self.initial_population,
            lower_t_bound=self.beginning_number_of_months,
            upper_t_bound=self.final_number_of_months,
            steps=20,
        )

        return solver.solve()

    def _get_mosquito_population_function(self, growth: GrowthIndex, set: SetIndex):
        effort_effectiveness = self.efforts_effectiveness[set]
        local_load_capacity = self.local_load_capacities[set]
        return (
            self._growth_constants[growth]
            * Variables.y
            * (1 - Variables.y / local_load_capacity)
            - effort_effectiveness * Variables.y
        )
