from src.solvers import EulerSolver
from .scenario import Scenario


class ScenarioA(Scenario):
    def __init__(self, solver_type: type[EulerSolver]) -> None:
        super().__init__(solver_type)
        self.local_load_capacities = (10.5, 10.0, 10.5)
        self.efforts_effectiveness = (0.55, 0.60, 0.50)
