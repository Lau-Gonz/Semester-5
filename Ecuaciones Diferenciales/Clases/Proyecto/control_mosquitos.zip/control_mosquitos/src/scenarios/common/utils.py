from .types import MosquitoPopulations, MosquitoPopulation


def merge_mosquito_populations(
    a: MosquitoPopulations, b: MosquitoPopulations
) -> MosquitoPopulations:
    c: MosquitoPopulations = get_empty_mosquito_populations()

    for set in c.keys():
        for growth in c[set].keys():
            c[set][growth] = a[set][growth] + b[set][growth]

    return c


def get_empty_mosquito_populations() -> MosquitoPopulations:
    return {
        "set_1": get_empty_mosquito_population(),
        "set_2": get_empty_mosquito_population(),
        "set_3": get_empty_mosquito_population(),
    }

def get_empty_mosquito_population() -> MosquitoPopulation:
    return {
        "growth_1": [],
        "growth_2": []
    }