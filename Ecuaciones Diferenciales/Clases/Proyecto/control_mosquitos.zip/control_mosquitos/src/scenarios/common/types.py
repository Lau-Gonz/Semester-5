from typing import TypedDict, Literal

GrowthIndex = Literal[0, 1]
SetIndex = Literal[0, 1, 2]




class MosquitoPopulation(TypedDict):
    growth_1: list[float]
    growth_2: list[float]

    @staticmethod # type: ignore
    def keys():
        return MosquitoPopulation.__annotations__.keys()

class MosquitoPopulations(TypedDict):
    set_1: MosquitoPopulation
    set_2: MosquitoPopulation
    set_3: MosquitoPopulation

    @staticmethod # type: ignore
    def keys():
        return MosquitoPopulations.__annotations__.keys()