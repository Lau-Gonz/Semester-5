from src.solvers import EulerSolver
from .scenario import Scenario


class ScenarioC(Scenario):
    def __init__(self, solver_type: type[EulerSolver]) -> None:
        super().__init__(solver_type)
        self.local_load_capacities = (9.0, 8.5, 9.0)
        self.efforts_effectiveness = (0.40, 0.45, 0.40)
