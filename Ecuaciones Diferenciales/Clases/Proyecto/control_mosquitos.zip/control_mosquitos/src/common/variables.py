from sympy import Symbol


class Variables:
    t = Symbol("t")
    y = Symbol("y")
