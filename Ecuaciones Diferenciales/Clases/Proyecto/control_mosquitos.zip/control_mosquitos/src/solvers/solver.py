from abc import ABC, abstractmethod
from sympy import Expr, Function, integrate
from src.common import Variables
from typing import cast


class Solver(ABC):
    current_step: int
    steps: int

    initial_y_condition: float
    current_y: float
    next_y: float
    defined_y: float | None = None

    initial_t_condition: float
    current_t: float
    next_t: float
    defined_t: float | None = None

    function: Expr
    integral_function: Expr

    def __init__(
        self,
        function: Expr,
        initial_t_condition: float,
        initial_y_condition: float,
        steps: int,
    ) -> None:
        assert steps > 0, ValueError("Max Iterations must be greater than 0")
        self.steps = steps
        self.current_step = 0

        self.function = function
        self.integral_function = cast(Function, integrate(function, Variables.t))

        self.initial_t_condition = initial_t_condition
        self.next_t = initial_t_condition

        self.initial_y_condition = initial_y_condition
        self.next_y = initial_y_condition

    def solve(self):
        while self.defined_y is None:
            self._solution_step()
        return self.defined_y

    def _solution_step(self):
        if self.current_step >= self.steps:
            self.defined_t = self.next_t
            self.defined_y = self.next_y
            return

        self._compute_current_step()

        self._compute_current_t()
        self._compute_current_y()

    def _compute_current_step(self):
        self.current_step += 1

    @abstractmethod
    def _compute_current_t(self):
        raise NotImplementedError

    @abstractmethod
    def _compute_current_y(self):
        raise NotImplementedError
