from .euler_solver import EulerSolver
from sympy import Expr
from typing import cast
from src.common import Variables


class RungeKutta(EulerSolver):
    _f1: Expr
    _f2: Expr
    _f3: Expr
    _f4: Expr

    initial_y_condition: float
    current_y: float
    next_y: float
    defined_y: float | None = None

    initial_t_condition: float
    current_t: float
    next_t: float
    defined_t: float | None = None

    def _compute_current_y(self):
        self.current_y = self.next_y

        self._compute_f1()
        self._compute_f2()
        self._compute_f3()
        self._compute_f4()

        self.next_y = float(
            (
                self.current_y + (self._f1 + 2 * self._f2 + 2 * self._f3 + self._f4) / 6
            ).subs({Variables.t: self.current_t})
        )

    def _compute_f1(self):
        self._f1 = self.step_size * cast(
            Expr,
            self.function.subs(
                {Variables.t: self.current_t, Variables.y: self.current_y}
            ),
        )

    def _compute_f2(self):
        self._f2 = self.step_size * cast(
            Expr,
            self.function.subs(
                {
                    Variables.t: self.current_t + self.step_size / 2,
                    Variables.y: self.current_y + self._f1 / 2,
                }
            ),
        )

    def _compute_f3(self):
        self._f3 = self.step_size * cast(
            Expr,
            self.function.subs(
                {
                    Variables.t: self.current_t + self.step_size / 2,
                    Variables.y: self.current_y + self._f2 / 2,
                }
            ),
        )

    def _compute_f4(self):
        self._f4 = self.step_size * cast(
            Expr,
            self.function.subs(
                {
                    Variables.t: self.current_t + self.step_size,
                    Variables.y: self.current_y + self._f3,
                }
            ),
        )
