from .solver import Solver
from sympy import Expr
from src.common import Variables
from typing import cast


class EulerSolver(Solver):
    step_size: float
    lower_t_bound: float
    upper_t_bound: float

    def __init__(
        self,
        function: Expr,
        initial_t_condition: float,
        initial_y_condition: float,
        lower_t_bound: float,
        upper_t_bound: float,
        steps: int,
    ) -> None:
        super().__init__(function, initial_t_condition, initial_y_condition, steps)
        self.lower_t_bound = lower_t_bound
        self.upper_t_bound = upper_t_bound
        self._compute_step_size()

    def _compute_current_t(self):
        self.current_t = self.next_t
        self.next_t = self.initial_t_condition + self.current_step * self.step_size

    def _compute_current_y(self):
        self.current_y = self.next_y
        self.next_y = float(
            self.current_y
            + self.step_size
            * cast(
                Expr,
                self.function.subs(
                    {Variables.t: self.current_t, Variables.y: self.current_y}
                ),
            )
        )

    def _compute_step_size(self):
        self.step_size = (self.upper_t_bound - self.lower_t_bound) / self.steps
