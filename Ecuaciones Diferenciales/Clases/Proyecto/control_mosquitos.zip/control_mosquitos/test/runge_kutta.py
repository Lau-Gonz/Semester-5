import unittest
from src.solvers import RungeKutta
from src.common import Variables


class TestRungeKutta(unittest.TestCase):
    def test_solve(self):
        rkn = RungeKutta(
            function=Variables.y - Variables.t**2 + 1,
            initial_t_condition=0,
            initial_y_condition=0.5,
            lower_t_bound=0,
            upper_t_bound=2,
            steps=4,
        )
        expected_result = round(5.301605, 4)
        result = round(
            rkn.solve(),
            4,
        )

        self.assertEqual(result, expected_result)
