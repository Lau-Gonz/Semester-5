% Creado por Dafne Castellanos y Laura Gonzalez
function fft_diezmado(filename)
    % Cargar las señales desde el archivo .mat
    data = load(filename);
    t = data.t;
    y1 = data.y1;
    y2 = data.y2;
    y3 = data.y3;
    % Calcular la FFT por diezmado para cada señal
    signals = {y1, y2, y3};
    for i = 1:numel(signals)
        signal = signals{i};
        N = numel(signal);
        % Calcular el número de puntos de la FFT
        N_fft = 2^nextpow2(N);
        % Asegurarse de que N_fft sea una potencia de 2
        if N_fft < N
            N_fft = N_fft * 2;
        end
        % Aplicar la FFT por diezmado
        fft_result = fft(signal, N_fft)/N;
        fft_result = fft_result(1:N_fft/2+1);
        fft_result(2:end-1) = 2*fft_result(2:end-1);
        % Calcular el vector de frecuencia
        f = (0:N_fft/2) / (N_fft*t(2));
        % Mostrar el resultado
        figure;
        plot(f, abs(fft_result));
        xlabel('Frecuencia');
        ylabel('Amplitud');
        title(['FFT por diezmado de la señal ', num2str(i), ' en Matlab']);
    end
end
