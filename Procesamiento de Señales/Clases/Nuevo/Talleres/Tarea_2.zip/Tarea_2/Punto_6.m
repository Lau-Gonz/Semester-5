%% Punto 7
% Dafne Castellanos y Laura Gonzalez

clear
clc
close all

syms f(t) g(t);  % Define f(t) y g(t) como símbolos simbólicos

A = 3;   % Asigna el valor 3 a la variable A
B = 4;   % Asigna el valor 4 a la variable B


ode1 = diff(f) == -A*f + g + heaviside(t - 1);   % Define la primera ecuación diferencial ode1
ode2 = diff(g) == diff(f) - B * g;               % Define la segunda ecuación diferencial ode2
cond1 = f(0) == 0;                               % Define la primera condición inicial cond1
cond2 = g(0) == 0;                               % Define la segunda condición inicial cond2

odes = [ode1; ode2];   % Crea un vector con las ecuaciones diferenciales odes
conds = [cond1; cond2];   % Crea un vector con las condiciones iniciales conds

S = dsolve(odes, conds);   % Resuelve el sistema de ecuaciones diferenciales con las condiciones iniciales

S.g = simplify(S.g);   % Simplifica la solución para g(t)
S.f = simplify(S.f);   % Simplifica la solución para f(t)
disp(S);  % Muestra la solución
disp(latex(S.g));

t_lins = linspace(0, 10, 1000);
plot(t_lins, subs(S.g, t, t_lins)) % Grafica S.g en función el tiempo t
title('Salida g(t)')

%%
syms s;
disp(latex(simplify(laplace(S.g,t,s))));


