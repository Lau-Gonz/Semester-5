%% Punto 7 Comprobación en Matlab
% Dafne Castellanos y Laura Gonzalez.

% Limpia la ventana de comandos, la ventana de trabajo y todas las figuras
clear
clc
close all

% Asigna valores a las variables A, B y K
A = 3;
B = 4;
K = [B 3*B 9*B 15*B 200*B 1000*B];

% Crea un vector 't' con 1000 puntos equidistantes entre 0 y 1
t = linspace(0, 1, 1000);

% Inicializa la variable 'y' con valor cero
y = 0;

% Itera sobre los elementos de 'K'
for k = K
    % Calcula el coseno de una función sinusoidal y lo suma a 'y'
    y = y + cos(2 * pi * k * t + A);
end

% Grafica el vector 't' en el eje x y 'y' en el eje y
plot(t, y)
