clear all
clc
j=1;
b=0;
c=0;
T=2;


for a=-10:0.5:10
 
c(j)=a; 
i=1;


for t=-10:0.01:10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%caso 1    
% x(i)=exp(-t)*paso(t,0);
% h(i) = paso(a-t,0);
% uh1(i)=h(i)*x(i);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%caso2    
paso=ustep(t);
h(i)=2*(paso((t+2),b)-paso((t-2),b));
u2(i)=exp(-abs(a-t));
u3(i)=(paso((t+4),a)-paso((t-4),a));
x(i)=u2(i)*u3(i);
uh1(i)=h(i)*x(i);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%case 3
% x(i)=(paso((t),b)-paso((t-2),b));
% if t<=2*T && t>0
% h(i)=t;
% else
%     h(i)=0;
% end
% %h(i)=(t)*paso(-t,a)-(t)*paso(-t+4,a);
% f= fliplr(h);
%  Xm = wshift('1D',f,-a*100);
% 
% uh1=x.*Xm;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%h2(i)=2*(paso((t+2),a)-paso((t-2),a));

%u8(i)=(paso((t+4),b)-paso((t-4),b));
%u2(i)=u7(i)*u8(i);
%uh2(i)=h2(i)*u2(i);


time(i)=t;
 i=i+1;

end

%conv2=max(cumtrapz(uh2));
conv1=0.01*max(cumtrapz(uh1));
k(j)=conv1;
%k2(j)=conv2;

% if (j>-6) && (j<-2)
%     y(j)=2*exp(j+2)-exp(4);
% elseif (-2<=j) && (j<2)
%     y(j)=4-2*exp(j-2)-2*exp(-j-2);
% elseif (2<=j) && (j<6)
%     y(j)=-2*(exp(-4)-exp(-j+2));
% else
%      y(j)=0;
% end 
%figure(1)

%y=conv(u1,u4);
tiledlayout(2,1)
set(gcf,'color','w')

%fig = figure(1);
% Top plot
subplot(311)
ax = gca;
set(gca,'fontsize',12);
%ax.XAxis.FontSize = 14;
%ax.YAxis.FontSize = 14;
%fontSize = 14;
%l.FontSize = 14;
yyaxis left
plot(time,h,'LineWidth',2)
t1 = title('h(t-\tau) shifting over t');
t1.Color = 'blue';
xlabel('\tau') 
ylabel('x(\tau)') 
% Bottom plot
hold on
%ax2 = nexttile;
yyaxis right
plot(time,x,'LineWidth',2)

ylabel('h(t-\tau)')
%
subplot(312)
ax = gca;
set(gca,'fontsize',12);
%fontSize = 14;
box on
hold on
xlabel('\tau')
t2 = title('u(\tau)*h(t-\tau)');
t2.Color='blue';
plot(time,uh1,'LineWidth',2)


subplot(313)
ax = gca;
set(gca,'fontsize',12);
fontSize = 14;
box on
hold on
xlabel('t')
t3 = title('\intu(\tau)*h(t-\tau)d\tau');
t3.Color='blue';
plot(c,k,'r','LineWidth',2)
pause(0.2)

% F1(j) = getframe(fig);
      drawnow

 j=j+1;
 
 
end
%movie(F)
% create the video writer with 1 fps
%   writerObj = VideoWriter('myVideo_2.avi');
%   writerObj.FrameRate = 10;
%   % set the seconds per image
% % open the video writer
% open(writerObj);
% % write the frames to the video
% all_valid = true;
% flen = length(F1);
% for K = 1 : flen
%   if isempty(F1(K).cdata)
%     all_valid = false;
%     fprintf('Empty frame occurred at frame #%d of %d\n', K, flen);
%   end
% end
% if ~all_valid
%    error('Did not write movie because of empty frames')
% end
% for i=1:length(F1)
%     % convert the image to a frame
%     frame = F1(i) ;    
%     writeVideo(writerObj, frame);
% end
% % close the writer object
% close(writerObj);
% %figure(2)
% %subplot(211)
% %plot(c,k)
% %subplot(212)
% %plot(c,k2)
% %subplot(222)
% %plot(time,u2)
% %plot(time,u3)
% 
% %subplot(222)


function [d] = pulse(t)
d = (t==0);
end

function [u] = ustep(t)
u = (t>=0);
end

function [r] = ramp(t)
r = t.*(t>=0);
end
